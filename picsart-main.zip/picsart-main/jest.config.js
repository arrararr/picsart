// @ts-check
module.exports = {
  setupFilesAfterEnv: ["<rootDir>/packages/commons/src/tests/jest-setup.ts"],
  testEnvironment: "jsdom",
  moduleNameMapper: {
    "\\.(scss|sass|css)$": "identity-obj-proxy",
    "^@ui-kit/(.*)": "<rootDir>/packages/ui-kit/src/$1",
    "^@app/(.*)": "<rootDir>/packages/app/src/$1",
  },
};
