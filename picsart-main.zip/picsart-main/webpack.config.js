/* eslint-disable @typescript-eslint/no-var-requires */
require("dotenv").config();

const CssMinimizerPlugin = require("css-minimizer-webpack-plugin");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const path = require("path");
const TsconfigPathsPlugin = require("tsconfig-paths-webpack-plugin");
const webpack = require("webpack");
const BundleAnalyzerPlugin =
  require("webpack-bundle-analyzer").BundleAnalyzerPlugin;

function setupWebpack({ entry, port, mode, devPlugins = [] }) {
  const isDevelopment = mode === "development";

  const plugins = [
    new MiniCssExtractPlugin({
      filename: "main-client.css",
    }),
    new webpack.DefinePlugin({
      ENV: JSON.stringify(process.env.ENV),
    }),
  ];

  if (process.env.BUNDLE_ANALYZE) {
    plugins.push(new BundleAnalyzerPlugin());
  }

  if (isDevelopment) {
    plugins.push(
      new HtmlWebpackPlugin({
        template: "../../public/index.html",
      }),
    );
    if (devPlugins.length) {
      plugins.push(...devPlugins);
    }
  }

  return {
    entry,
    cache: false,
    mode,
    externals: {
      react: "React",
      "react-dom": "ReactDOM",
      "react-redux": "ReactRedux",
    },
    optimization: {
      minimize: !isDevelopment,
      splitChunks: {
        //chunks: "async",
        cacheGroups: {
          reactRouter: {
            test: /[\\/]node_modules[\\/](react-router)[\\/]/,
            name: "react-router",
            chunks: "all",
          },
          reactRouterDom: {
            test: /[\\/]node_modules[\\/](react-router-dom)[\\/]/,
            name: "react-router-dom",
            chunks: "all",
          },
          reduxToolkit: {
            test: /[\\/]node_modules[\\/]@reduxjs[\\/]toolkit[\\/]/,
            name: "redux-toolkit",
            chunks: "all",
          },
        },
      },
      removeAvailableModules: true,
      minimizer: [
        "...",
        new CssMinimizerPlugin({
          minimizerOptions: {
            preset: [
              "default",
              {
                csso: {
                  restructure: false,
                },
              },
            ],
          },
        }),
      ],
    },
    devServer: {
      static: {
        directory: path.join(__dirname, "public"),
      },
      hot: true,
      historyApiFallback: true,
      port,
    },
    output: {
      filename: "[name].js",
      publicPath: "auto",
      path: path.resolve(__dirname, "dist"),
      chunkFilename: "[name].[contenthash].js",
    },
    resolve: {
      extensions: [".tsx", ".ts", ".jsx", ".js", ".json", ".scss"],
      modules: [path.join(__dirname), "node_modules"],
      plugins: [new TsconfigPathsPlugin()],
    },
    module: {
      rules: [
        {
          test: /\.jsx?$/,
          loader: require.resolve("babel-loader"),
          exclude: /node_modules/,
          options: {
            presets: [require.resolve("@babel/preset-react")],
          },
        },
        {
          test: /\.tsx?$/,
          exclude: /node_modules/,
          use: {
            loader: "ts-loader",
            options: {
              projectReferences: true,
            },
          },
        },
        {
          test: /\.s(a|c)ss$/,
          use: [
            isDevelopment ? "style-loader" : MiniCssExtractPlugin.loader,
            {
              loader: "css-loader",
              options: {
                importLoaders: 1,
                modules: {
                  auto: true,
                  exportGlobals: true,
                  localIdentName: "[local]--[hash:base64:6]",
                },
              },
            },
            {
              loader: "sass-loader",
            },
          ],
        },
      ],
    },

    plugins: [...plugins],
  };
}

module.exports = setupWebpack;
