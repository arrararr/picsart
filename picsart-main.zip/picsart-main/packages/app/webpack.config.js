/* eslint-disable @typescript-eslint/no-var-requires */
const { NODE_ENV } = process.env;

/* eslint-disable @typescript-eslint/no-var-requires */
require("dotenv").config();

const setupWebpack = require("../../webpack.config");

module.exports = setupWebpack({
  entry: NODE_ENV === "production" ? "./src/index.tsx" : "./src/dev.tsx",
  mode: NODE_ENV || "development",
  port: 3001,
});
