import { App } from "@app/app";
import { PreloadedState } from "@app/stores/types";
import { FC } from "react";

type Props = {
  preloadedState?: PreloadedState;
};

const Entry: FC<Props> = ({ preloadedState = {} }) => (
  <html lang="en">
    <head>
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <link rel="preconnect" href="https://cdnjs.cloudflare.com" />
      <link rel="preconnect" href="https://unpkg.com" />
      <meta charSet="UTF-8" />
      <title>Picsart</title>
      <meta name="description" content="Description of the page for SEO" />
      <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,800&display=swap"
        type="text/css"
        rel="preload"
        as="stylesheet"
      />
      <link rel="stylesheet" href="/static/main.css" />
      <script
        crossOrigin=""
        src="https://unpkg.com/react@18.2.0/umd/react.production.min.js"
        defer={true}
      ></script>
      <script
        crossOrigin=""
        src="https://unpkg.com/react-dom@18.2.0/umd/react-dom.production.min.js"
        defer={true}
      ></script>
      <script
        crossOrigin=""
        src="https://cdnjs.cloudflare.com/ajax/libs/react-redux/8.1.3/react-redux.min.js"
        defer={true}
      ></script>
      <script src="/static/react-router.js" defer={true}></script>
      <script src="/static/react-router-dom.js" defer={true}></script>
      <script src="/static/redux-toolkit.js" defer={true}></script>
      <style
        dangerouslySetInnerHTML={{
          __html: `* {
            font-family: "Open Sans", "Helvetica Neue", sans-serif;
            box-sizing: border-box;
        }

        body {
            margin: 0;
        }

        #root {
            position: absolute;
            width: 100%;
            min-height: 100%;
            display: flex;
        }`,
        }}
      />
    </head>
    <body>
      <div id="root">
        <App />
      </div>
      <div
        dangerouslySetInnerHTML={{
          __html: `<script>
          if (typeof window === "undefined") {
            window = {}
          }
          window["REDUX_INITIAL_STATE"] = ${JSON.stringify(
            preloadedState,
          ).replace(/</g, "\\\u003c")};</script>`,
        }}
      />
      <script src="/static/main.js" defer={true}></script>
      <link rel="stylesheet" href="/static/main-client.css" />
    </body>
  </html>
);

export default Entry;
