import { State } from "@app/stores/types";

export const getInitialDataFromServer = () => {
  try {
    if (typeof window !== "undefined") {
      return window["REDUX_INITIAL_STATE"] || ({} as State);
    }
  } catch {
    console.log("incorrect initial state");
  }

  return {} as State;
};
