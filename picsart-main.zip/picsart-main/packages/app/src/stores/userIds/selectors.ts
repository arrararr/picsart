import { State } from "../types";

export const getUserIds = (state: State) => {
  return state.userIds;
};
