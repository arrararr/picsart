import { getInitialDataFromServer } from "@app/helpers";
import { fetchUsers } from "@app/stores/users";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";

export type UserIdsState = string[];

const DEFAULT_STATE = [] as UserIdsState;

const initialState: UserIdsState =
  getInitialDataFromServer().userIds || DEFAULT_STATE;

export const userIds = createSlice({
  name: "userIds",
  initialState,
  reducers: {
    saveUserIds: (_: UserIdsState, action: PayloadAction<UserIdsState>) => {
      return action.payload;
    },
    resetUserIds: () => DEFAULT_STATE,
  },
  extraReducers: (builder) => {
    builder.addCase(fetchUsers.fulfilled, (_, action) => {
      return action.payload.users.map(({ _id }) => _id);
    });
  },
});

export const { resetUserIds } = userIds.actions;

export const userIdsReducer = userIds.reducer;
