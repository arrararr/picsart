import { UiState } from "@app/stores/ui";
import { UserState } from "@app/stores/user";
import { UserFilterState } from "@app/stores/userFilter";
import { UserIdsState } from "@app/stores/userIds";
import { UsersState } from "@app/stores/users";

import { store } from "./";

export type State = ReturnType<typeof store.getState>;
export type Dispatch = typeof store.dispatch;
export type PreloadedState = {
  users?: UsersState;
  user?: UserState;
  userIds?: UserIdsState;
  userFilter?: UserFilterState;
  ui?: UiState;
};
