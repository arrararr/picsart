import { configureStore } from "@reduxjs/toolkit";

import { uiReducer } from "./ui";
import { userReducer } from "./user";
import { userFilterReducer } from "./userFilter";
import { userIdsReducer } from "./userIds";
import { usersReducer } from "./users";

export const store = configureStore({
  reducer: {
    user: userReducer,
    users: usersReducer,
    userIds: userIdsReducer,
    userFilter: userFilterReducer,
    ui: uiReducer,
  },
});
