import { getInitialDataFromServer } from "@app/helpers";
import { fetchUsers } from "@app/stores/users";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";

import { Pagination, UserFilterState } from "./types";

const DEFAULT_STATE = {
  sort: null,
  search: null,
  pagination: null,
};

const initialState: UserFilterState =
  getInitialDataFromServer().userFilter || DEFAULT_STATE;

export const userFilter = createSlice({
  name: "userFilter",
  initialState,
  reducers: {
    setPagination: (
      state: UserFilterState,
      action: PayloadAction<Pagination>,
    ) => {
      return {
        ...state,
        pagination: action.payload,
      };
    },
    setPage: (state: UserFilterState, action: PayloadAction<number>) => {
      return {
        ...state,
        pagination: {
          ...(state.pagination || {
            total: 0,
          }),
          page: action.payload,
        },
      };
    },
    setSearch: (state: UserFilterState, action: PayloadAction<string>) => {
      return {
        ...state,
        search: action.payload,
      };
    },
    setSort: (state: UserFilterState, action: PayloadAction<string>) => {
      return {
        ...state,
        sort: action.payload,
      };
    },
    resetUserFilter: () => DEFAULT_STATE,
  },
  extraReducers: (builder) => {
    builder.addCase(fetchUsers.fulfilled, (state, action) => {
      const pagination = {
        total: action.payload.pagination.total,
        page: action.payload.pagination.page + 1,
      };

      return {
        ...state,
        pagination,
      };
    });
  },
});

export const { setSort, setSearch, setPage, resetUserFilter } =
  userFilter.actions;

export const userFilterReducer = userFilter.reducer;
