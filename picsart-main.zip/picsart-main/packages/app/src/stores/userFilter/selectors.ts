import { createSelector } from "@reduxjs/toolkit";

import { State } from "../types";

import { ITEMS_PER_PAGE } from "./constants";

const getUserFilter = (state: State) => state.userFilter;

export const getSort = createSelector(
  getUserFilter,
  (userFilter) => userFilter.sort,
);

export const getSearch = createSelector(
  getUserFilter,
  (userFilter) => userFilter.search,
);

export const getPagination = createSelector(
  getUserFilter,
  (userFilter) => userFilter.pagination,
);

export const getCurrentPage = createSelector(
  getPagination,
  (pagination) => pagination?.page ?? undefined,
);

export const getTotalItems = createSelector(
  getPagination,
  (pagination) => pagination?.total ?? undefined,
);

export const checkIfShouldShowPagination = createSelector(
  getTotalItems,
  (total) => (total || 0) / ITEMS_PER_PAGE > 1,
);
