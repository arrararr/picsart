export type Pagination = {
  total: number;
  page: number;
};

export type UserFilterState = {
  sort: string | null;
  search: string | null;
  pagination: Pagination | null;
};
