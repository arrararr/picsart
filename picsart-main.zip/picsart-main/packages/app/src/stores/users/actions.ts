import { createAsyncThunk } from "@reduxjs/toolkit";

import { get } from "@ui-kit/helpers/requests";

import { FetchUsersParams, FetchUsersResult } from "./types";

const SORT_FIELD_MAP: Record<string, string> = {
  name: "name",
  age: "age",
  _id: "_id",
};

export const fetchUsers = createAsyncThunk<FetchUsersResult, FetchUsersParams>(
  "filter/fetchUsers",
  async ({ sort, search, page }) => {
    const preparedParams = {
      sort: SORT_FIELD_MAP[sort || ""] || "_id",
      search: (search || "").trim(),
      page: String((page || 1) - 1),
    };
    const searchParams = new URLSearchParams();

    Object.entries(preparedParams).forEach(([key, value]) => {
      if (value) {
        searchParams.append(key, value);
      }
    });

    const queryString = searchParams.toString();

    const res = await get<FetchUsersResult>(
      `/api/users${queryString.length ? `?${queryString}` : ""}`,
    );

    return res;
  },
);
