import { User } from "@app/stores/user";
import { Pagination } from "@app/stores/userFilter";

import { RequestStatus } from "@ui-kit/enums";

export type Users = Record<string, User>;

export type UsersState = {
  users: Users;
  fetchingStatus?: RequestStatus;
};

export type FetchUsersParams = {
  sort: string;
  search: string;
  page: number;
};

export type FetchUsersResult = {
  users: User[];
  pagination: Pagination;
};
