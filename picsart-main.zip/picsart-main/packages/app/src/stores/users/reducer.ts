import { getInitialDataFromServer } from "@app/helpers";
import { createSlice } from "@reduxjs/toolkit";

import { RequestStatus } from "@ui-kit/enums";

import { fetchUsers } from "./actions";
import { Users, UsersState } from "./types";

const DEFAULT_STATE = {
  users: {},
};
const initialState: UsersState =
  getInitialDataFromServer().users || DEFAULT_STATE;

export const users = createSlice({
  name: "users",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(fetchUsers.fulfilled, (state, action) => {
      return {
        users: action.payload.users.reduce((acc, item) => {
          acc[item._id] = item;
          return acc;
        }, {} as Users),
        fetchingStatus: RequestStatus.Fulfilled,
      };
    });
    builder.addCase(fetchUsers.pending, (state) => {
      return {
        ...state,
        fetchingStatus: RequestStatus.Pending,
      };
    });
    builder.addCase(fetchUsers.rejected, (state) => {
      return {
        ...state,
        fetchingStatus: RequestStatus.Rejected,
      };
    });
  },
});
export const usersReducer = users.reducer;
