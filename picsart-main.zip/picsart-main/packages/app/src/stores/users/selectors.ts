import { createSelector } from "@reduxjs/toolkit";

import { RequestStatus } from "@ui-kit/enums";

import { State } from "../types";

export const getUsers = (state: State) => {
  return state.users.users;
};

export const checkIfFetchingUsers = (state: State) =>
  state.users.fetchingStatus === RequestStatus.Pending;

export const getUserById = createSelector(
  [getUsers, (_, id: string) => id],
  (users, id) => users[id],
);

export const getUserName = createSelector(
  getUserById,
  (user) => user?.name ?? undefined,
);
export const getUserLastName = createSelector(
  getUserById,
  (user) => user?.lastName ?? undefined,
);
export const getUserAge = createSelector(
  getUserById,
  (user) => user?.age ?? undefined,
);
export const getUserDescription = createSelector(
  getUserById,
  (user) => user?.description ?? undefined,
);
export const getUserEmail = createSelector(
  getUserById,
  (user) => user?.email ?? undefined,
);
export const getUserAddress = createSelector(
  getUserById,
  (user) => user?.address ?? undefined,
);
