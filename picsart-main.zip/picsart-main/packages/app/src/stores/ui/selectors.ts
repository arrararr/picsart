import { State } from "@app/stores/types";

export const checkIfDarkMode = (state: State) => {
  return state.ui.theme === "dark";
};
