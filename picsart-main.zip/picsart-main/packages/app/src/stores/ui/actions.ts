import { setCookie } from "@app/helpers";
import { createAsyncThunk } from "@reduxjs/toolkit";

import { Theme } from "./types";

export const setTheme = createAsyncThunk<Theme, Theme>(
  "ui/setTheme",
  async (theme) => {
    setCookie("theme", theme, 365);

    return theme;
  },
);
