import { getInitialDataFromServer } from "@app/helpers";
import { setTheme } from "@app/stores/ui/actions";
import { createSlice } from "@reduxjs/toolkit";

import { Theme } from "./types";

export type UiState = {
  theme: Theme;
};

const initialState: UiState = getInitialDataFromServer().ui || {
  theme: "light",
};

export const ui = createSlice({
  name: "ui",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder.addCase(setTheme.fulfilled, (state, action) => {
      return {
        ...state,
        theme: action.payload,
      };
    });
  },
});

export const uiReducer = ui.reducer;
