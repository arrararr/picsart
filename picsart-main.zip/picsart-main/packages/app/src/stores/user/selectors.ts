import { createSelector } from "@reduxjs/toolkit";

import { RequestStatus } from "@ui-kit/enums";

import { State } from "../types";

export const getUser = (state: State) => {
  return state.user.user;
};
export const checkIfUserIsAdding = (state: State) => {
  return state.user.statusAdding === RequestStatus.Pending;
};
export const checkIfUserAddingError = (state: State) => {
  return state.user.statusAdding === RequestStatus.Rejected;
};
export const checkIfUserAddingFulfilled = (state: State) => {
  return state.user.statusAdding === RequestStatus.Fulfilled;
};
export const checkIfUserIsFetching = (state: State) => {
  return state.user.statusFetching === RequestStatus.Pending;
};

export const getUserId = createSelector(
  getUser,
  (user) => user?._id ?? undefined,
);
export const getUserName = createSelector(
  getUser,
  (user) => user?.name ?? undefined,
);
export const getUserLastName = createSelector(
  getUser,
  (user) => user?.lastName ?? undefined,
);
export const getUserEmail = createSelector(
  getUser,
  (user) => user?.email ?? undefined,
);
export const getUserAddress = createSelector(
  getUser,
  (user) => user?.address ?? undefined,
);
export const getUserAge = createSelector(
  getUser,
  (user) => user?.age ?? undefined,
);
export const getUserDescription = createSelector(
  getUser,
  (user) => user?.description ?? undefined,
);
