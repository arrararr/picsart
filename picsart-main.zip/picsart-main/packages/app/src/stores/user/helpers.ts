import { del } from "@ui-kit/helpers/requests";

export const deleteUser = async (userId: string) => {
  const res = await del<boolean>(`/api/users/${userId}`);

  return res;
};
