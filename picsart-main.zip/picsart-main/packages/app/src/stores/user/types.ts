import { RequestStatus } from "@ui-kit/enums";

export type User = {
  _id: string;
  name: string;
  lastName: string;
  email: string;
  age: string;
  address: string;
  description: string;
};

export type UserState = {
  statusAdding?: RequestStatus;
  statusFetching?: RequestStatus;
  user: User | null;
};

export type AddUserParams = Omit<User, "_id"> & {
  file: File | null;
};
export type FetchUserResult = User;
