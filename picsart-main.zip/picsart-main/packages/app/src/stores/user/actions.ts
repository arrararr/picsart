import { State } from "@app/stores/types";
import { getCurrentPage, getSearch, getSort } from "@app/stores/userFilter";
import { fetchUsers, getUserById } from "@app/stores/users";
import { createAsyncThunk } from "@reduxjs/toolkit";

import { get, post } from "@ui-kit/helpers/requests";

import { deleteUser } from "./helpers";
import { FetchUserResult, AddUserParams } from "./types";

export const addUser = createAsyncThunk<FetchUserResult, AddUserParams>(
  "user/createUser",
  async (params) => {
    const { file, ...user } = params;

    // TODO: split to 2 actions with separate error handlers
    const res = await post<FetchUserResult>(
      "/api/users/create",
      JSON.stringify(user),
      {
        "Content-Type": "application/json",
      },
    );

    const formData = new FormData();

    formData.append("file", file as File);

    await post(`/api/images/upload/${res._id}`, formData);

    return res;
  },
);

export const deleteUserAndUpdateList = createAsyncThunk<boolean, string>(
  "user/deleteUser",
  async (userId, { dispatch, getState }) => {
    const res = await deleteUser(userId);
    const state = getState() as State;

    dispatch(
      fetchUsers({
        page: getCurrentPage(state) || 1,
        search: getSearch(state) || "",
        sort: getSort(state) || "",
      }),
    );
    return res;
  },
);

export const fetchUserIfNeeded = createAsyncThunk<FetchUserResult, string>(
  "user/fetchUserIfNeeded",
  async (userId: string, { getState }) => {
    const state = getState();
    const currentUser = getUserById(state, userId);

    if (currentUser) {
      return currentUser;
    }

    const fetchedUser = await get<FetchUserResult>(`/api/users/${userId}`);

    return fetchedUser;
  },
);
