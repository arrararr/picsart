import { getInitialDataFromServer } from "@app/helpers";
import { createSlice } from "@reduxjs/toolkit";

import { RequestStatus } from "@ui-kit/enums";

import { addUser, fetchUserIfNeeded } from "./actions";
import { UserState } from "./types";

const DEFAULT_STATE = {
  user: null,
};

const initialState: UserState =
  getInitialDataFromServer().user || DEFAULT_STATE;

export const user = createSlice({
  name: "user",
  initialState,
  reducers: {
    resetUser: () => DEFAULT_STATE,
  },
  extraReducers: (builder) => {
    builder.addCase(fetchUserIfNeeded.fulfilled, (state, action) => {
      return {
        ...state,
        user: action.payload,
        statusFetching: RequestStatus.Fulfilled,
      };
    });
    builder.addCase(fetchUserIfNeeded.pending, (state) => {
      return {
        ...state,
        statusFetching: RequestStatus.Pending,
      };
    });
    builder.addCase(addUser.pending, (state) => {
      return {
        ...state,
        statusAdding: RequestStatus.Pending,
      };
    });
    builder.addCase(addUser.fulfilled, (state) => {
      return {
        ...state,
        statusAdding: RequestStatus.Fulfilled,
      };
    });
    builder.addCase(addUser.rejected, (state) => {
      return {
        ...state,
        statusAdding: RequestStatus.Rejected,
      };
    });
  },
});

export const { resetUser } = user.actions;

export const userReducer = user.reducer;
