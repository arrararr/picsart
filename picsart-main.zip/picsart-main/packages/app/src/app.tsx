import { Template } from "@app/components/Template";
import { FC, Suspense, lazy } from "react";
import { Route, Routes } from "react-router-dom";

const Home = lazy(() => import("@app/pages/Home"));
const Users = lazy(() => import("@app/pages/Users"));
const User = lazy(() => import("@app/pages/User"));
const ErrorPage = lazy(() => import("@app/pages/ErrorPage"));

export const App: FC = () => (
  <Template>
    <Routes>
      <Route
        path="/"
        element={
          <Suspense fallback={null}>
            <Home />
          </Suspense>
        }
      />
      <Route
        path="/users"
        element={
          <Suspense fallback={null}>
            <Users />
          </Suspense>
        }
      />
      <Route
        path="/users/:id"
        element={
          <Suspense fallback={null}>
            <User />
          </Suspense>
        }
      />
      <Route
        path="*"
        element={
          <Suspense fallback={null}>
            <ErrorPage code={404} />
          </Suspense>
        }
      />
    </Routes>
  </Template>
);
