import Entry from "@app/entry";
import { store } from "@app/stores";
import { hydrateRoot } from "react-dom/client";
import { Provider } from "react-redux";
import { BrowserRouter } from "react-router-dom";

hydrateRoot(
  document!,
  <Provider store={store}>
    <BrowserRouter basename="/">
      <Entry />
    </BrowserRouter>
  </Provider>,
);
