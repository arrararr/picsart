import ErrorBoundary from "@app/components/ErrorBoundary";
import { Header } from "@app/components/Header";
import ErrorPage from "@app/pages/ErrorPage";
import { checkIfDarkMode } from "@app/stores/ui";
import cn from "classnames";
import { FC, PropsWithChildren } from "react";
import { useSelector } from "react-redux";

import { Container } from "@ui-kit/components/Grid";

import styles from "./index.module.scss";

export const Template: FC<PropsWithChildren> = ({ children }) => {
  const isDark = useSelector(checkIfDarkMode);

  return (
    <div className={cn(styles.root, isDark && "dark-mode")}>
      <Header />
      <Container>
        <ErrorBoundary fallback={<ErrorPage />}>{children}</ErrorBoundary>
      </Container>
    </div>
  );
};
