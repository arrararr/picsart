import { ThemeToggler } from "@app/components/ThemeToggler";
import { FC } from "react";
import { NavLink } from "react-router-dom";

import { Container } from "@ui-kit/components/Grid";
import { Text3 } from "@ui-kit/typography";

import styles from "./index.module.scss";

export const Header: FC = () => {
  return (
    <div className={styles.root}>
      <Container className={styles.container}>
        <nav className={styles.nav}>
          <NavLink to="/" className={styles.item}>
            <Text3>Home</Text3>
          </NavLink>
          <NavLink to="/users" className={styles.item}>
            <Text3 className={styles.text}>Users</Text3>
          </NavLink>
        </nav>
        <ThemeToggler className={styles.toggler} />
      </Container>
    </div>
  );
};
