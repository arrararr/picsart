import { Dispatch } from "@app/stores/types";
import { checkIfDarkMode, setTheme } from "@app/stores/ui";
import cn from "classnames";
import { FC } from "react";
import { useDispatch, useSelector } from "react-redux";

import styles from "./index.module.scss";

type Props = {
  className?: string;
};

export const ThemeToggler: FC<Props> = ({ className }) => {
  const dispatch = useDispatch<Dispatch>();
  const isDark = useSelector(checkIfDarkMode);

  return (
    <div
      className={cn(styles.root, isDark && styles.left, className)}
      onClick={() => dispatch(setTheme(isDark ? "light" : "dark"))}
    >
      <div className={styles.inner} />
    </div>
  );
};
