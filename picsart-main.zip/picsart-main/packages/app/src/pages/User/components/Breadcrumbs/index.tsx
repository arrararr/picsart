import { getCurrentPage, getSearch, getSort } from "@app/stores/userFilter";
import { FC } from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";

import { Text3 } from "@ui-kit/typography";

import styles from "../../index.module.scss";

export const Breadcrumbs: FC = () => {
  const search = useSelector(getSearch) || "";
  const page = useSelector(getCurrentPage) || "";
  const sort = useSelector(getSort) || "";
  const params = Object.entries({ search, page, sort }).reduce(
    (acc, [key, value]) => {
      if (value) {
        acc[key] = String(value);
      }
      return acc;
    },
    {} as Record<string, string>,
  );
  const searchParams = new URLSearchParams(params).toString();
  return (
    <Text3 as="div" className={styles.breadcrumbs}>
      <Link
        to={`/users${searchParams.length ? `?${searchParams}` : ""}`}
        className={styles.link}
      >
        {"<< Back"}
      </Link>
    </Text3>
  );
};
