import { Dispatch } from "@app/stores/types";
import {
  fetchUserIfNeeded,
  getUserAddress,
  getUserDescription,
  getUserEmail,
  getUserLastName,
  getUserName,
  getUserAge,
  getUserId,
  resetUser,
} from "@app/stores/user";
import { FC, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams } from "react-router";

import { Block } from "@ui-kit/components/Grid";
import { H1, Text3 } from "@ui-kit/typography";

import { Breadcrumbs } from "./components";
import styles from "./index.module.scss";

const User: FC = () => {
  const { id: idFromUrl } = useParams();
  const storedId = useSelector(getUserId);
  const id = idFromUrl || storedId;
  const dispatch = useDispatch<Dispatch>();
  const name = useSelector(getUserName);
  const lastName = useSelector(getUserLastName);
  const email = useSelector(getUserEmail);
  const age = useSelector(getUserAge);
  const address = useSelector(getUserAddress);
  const description = useSelector(getUserDescription);

  const userName = `${name} ${lastName}`;

  useEffect(() => {
    if (id && !storedId) {
      dispatch(fetchUserIfNeeded(id));
    }
  }, [id, storedId, dispatch]);

  useEffect(() => {
    return () => {
      dispatch(resetUser());
    };
  }, [dispatch]);

  return (
    <div>
      <Breadcrumbs />
      <Block offsetTop="s">
        <H1>{userName}</H1>
      </Block>

      <Block offsetTop="s" className={styles.content}>
        <div className={styles.mainInfo}>
          <div className={styles.imageContainer}>
            <picture>
              <source
                type="image/webp"
                srcSet={`/images/${id}_400_400.webp 2x, /images/${id}_200_200.webp 1x`}
              />
              <source
                type="image/png"
                srcSet={`/images/${id}_400_400.png 2x, /images/${id}_200_200.png 1x`}
              />
              <img
                src={`/images/${id}_200_200.png`}
                alt={userName}
                loading="lazy"
                width="200"
                height="200"
              />
            </picture>
          </div>
          <ul className={styles.list}>
            <Text3 as="li" className={styles.label}>
              <span className={styles.labelName}>email</span>: {email}
            </Text3>
            <Text3 as="li" className={styles.label}>
              <span className={styles.labelName}>age</span>: {age}
            </Text3>
            <Text3 as="li" className={styles.label}>
              <span className={styles.labelName}>address</span>: {address}
            </Text3>
          </ul>
        </div>
        <div className={styles.description}>
          <Text3>{description}</Text3>
        </div>
      </Block>
    </div>
  );
};

export default User;
