import { FC } from "react";

import { ErrorMessage } from "@ui-kit/components/ErrorMessage";
import { Block } from "@ui-kit/components/Grid";
import { H1 } from "@ui-kit/typography";

type Props = {
  code?: number;
};

const ErrorPage: FC<Props> = ({ code }) => {
  return (
    <div>
      <H1>Error</H1>
      <Block offsetTop="s">
        <ErrorMessage>
          {code === 404 ? "Page not found" : "Something went wrong"}
        </ErrorMessage>
      </Block>
    </div>
  );
};

export default ErrorPage;
