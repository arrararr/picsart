export const SORT_OPTIONS = [
  {
    value: "",
    label: "By default",
  },
  {
    value: "name",
    label: "Name",
  },
  {
    value: "age",
    label: "Age",
  },
];
