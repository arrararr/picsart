import { UserCard } from "@app/pages/Users/components/UserCard";
import { FC } from "react";

import { Block } from "@ui-kit/components/Grid";

type Props = {
  userIds: string[];
};

export const UsersList: FC<Props> = ({ userIds }) => {
  return (
    <>
      {userIds.map((userId, index) => {
        if (index === 0) {
          return <UserCard id={userId} key={userId} />;
        }

        return (
          <Block offsetTop="s" key={userId}>
            <UserCard id={userId} />
          </Block>
        );
      })}
    </>
  );
};
