import {
  getCurrentPage,
  getTotalItems,
  ITEMS_PER_PAGE,
} from "@app/stores/userFilter";
import { FC } from "react";
import { useSelector } from "react-redux";

import { getAvailablePages } from "./helpers";
import styles from "./index.module.scss";
import { Item } from "./Item";

export const Pagination: FC = () => {
  const page = useSelector(getCurrentPage) || 1;

  const totalItems = useSelector(getTotalItems) || 0;
  const countOfPage = Math.ceil(totalItems / ITEMS_PER_PAGE);
  const pages = getAvailablePages(page, countOfPage);
  const previousPage = page - 1;
  const nextPage = page + 1;

  return (
    <ul className={styles.root}>
      {previousPage > 0 && <Item page={previousPage} isPrevious={true} />}

      {pages.map((item) => (
        <Item page={item} key={item} isActive={page === item} />
      ))}

      {nextPage <= countOfPage && <Item page={nextPage} isNext={true} />}
    </ul>
  );
};
