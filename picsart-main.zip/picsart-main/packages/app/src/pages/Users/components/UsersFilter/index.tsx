import { getSearch, getSort } from "@app/stores/userFilter";
import cn from "classnames";
import { FC, useId } from "react";
import { useSelector } from "react-redux";

import { Label, NativeSelect, TextField } from "@ui-kit/components";

import { SORT_OPTIONS } from "./constants";
import styles from "./index.module.scss";

type Props = {
  className?: string;
  onChange: (key: string, value: string) => void;
};

export const UsersFilter: FC<Props> = ({ className, onChange }) => {
  const sort = useSelector(getSort) || "";
  const search = useSelector(getSearch) || "";
  const searchId = useId();
  const sortId = useId();

  return (
    <div className={cn(styles.root, className)}>
      <Label text="Search" className={styles.search} id={searchId}>
        <TextField
          id={searchId}
          value={search}
          onChange={(value) => onChange("search", value)}
        />
      </Label>
      <Label text="Sort" className={styles.sort} id={sortId}>
        <NativeSelect
          id={sortId}
          value={sort}
          onChange={(value) => onChange("sort", value)}
          options={SORT_OPTIONS}
        />
      </Label>
    </div>
  );
};
