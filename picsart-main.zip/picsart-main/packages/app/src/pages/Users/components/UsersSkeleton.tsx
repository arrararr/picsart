import { FC } from "react";

import { Block } from "@ui-kit/components/Grid";

import { UserCardSkeleton } from "./UserCard/UserCardSkeleton";

export const UsersSkeleton: FC = () => {
  return (
    <>
      {new Array(10).fill(0).map((_, index) => {
        if (index === 0) {
          return <UserCardSkeleton key={index} />;
        }

        return (
          <Block offsetTop="s" key={index}>
            <UserCardSkeleton />
          </Block>
        );
      })}
    </>
  );
};
