import { Dispatch } from "@app/stores/types";
import { deleteUserAndUpdateList } from "@app/stores/user";
import {
  getUserAge,
  getUserEmail,
  getUserLastName,
  getUserName,
} from "@app/stores/users";
import { FC } from "react";
import { useDispatch, useSelector } from "react-redux";
import { NavLink } from "react-router-dom";

import { Button, ButtonStyle } from "@ui-kit/components";
import { Block } from "@ui-kit/components/Grid";
import { H2, Text3 } from "@ui-kit/typography";

import styles from "./index.module.scss";

type Props = {
  id: string;
};

export const UserCard: FC<Props> = ({ id }) => {
  const dispatch = useDispatch<Dispatch>();
  const name = useSelector((state) => getUserName(state, id));
  const lastName = useSelector((state) => getUserLastName(state, id));
  const age = useSelector((state) => getUserAge(state, id));
  const email = useSelector((state) => getUserEmail(state, id));
  const userName = `${name} ${lastName}`;

  return (
    <div className={styles.root}>
      <div className={styles.imageContainer}>
        <picture>
          <source
            type="image/webp"
            srcSet={`/images/${id}_200_200.webp 2x, /images/${id}_100_100.webp 1x`}
          />
          <source
            type="image/png"
            srcSet={`/images/${id}_200_200.png 2x, /images/${id}_100_100.png 1x`}
          />
          <img
            src={`/images/${id}_100_100.png`}
            alt={userName}
            loading="lazy"
            width="100"
            height="100"
          />
        </picture>
      </div>
      <div className={styles.info}>
        <H2>{userName}</H2>
        <Block offsetTop="xxs">
          <ul className={styles.list}>
            <li className={styles.label}>
              <Text3>
                <span className={styles.labelName}>email</span>: {email}
              </Text3>
            </li>
            <li className={styles.label}>
              <Text3>
                <span className={styles.labelName}>age</span>: {age}
              </Text3>
            </li>
          </ul>
        </Block>
      </div>
      <div className={styles.actions}>
        <NavLink to={`/users/${id}`}>
          <Button buttonStyle={ButtonStyle.Primary}>Open</Button>
        </NavLink>

        <Block offsetTop="s">
          <ul className={styles.actionsList}>
            <li>
              <Text3
                className={styles.actionItem}
                as="div"
                onClick={() => dispatch(deleteUserAndUpdateList(id))}
              >
                Delete
              </Text3>
            </li>
          </ul>
        </Block>
      </div>
    </div>
  );
};
