import { FC } from "react";

import { Skeleton } from "@ui-kit/components";
import { Block } from "@ui-kit/components/Grid";
import { getMockText } from "@ui-kit/helpers/getMockText";
import { H2, Text3 } from "@ui-kit/typography";

import styles from "./index.module.scss";

export const UserCardSkeleton: FC = () => {
  return (
    <div className={styles.root}>
      <Skeleton className={styles.imageContainer}></Skeleton>
      <div className={styles.info}>
        <H2>
          <Skeleton>{getMockText(30)}</Skeleton>
        </H2>
        <Block offsetTop="xxs">
          <ul className={styles.list}>
            <li className={styles.label}>
              <Text3>
                <Skeleton>{getMockText(45)}</Skeleton>
              </Text3>
            </li>
            <li className={styles.label}>
              <Text3>
                <Skeleton>{getMockText(35)}</Skeleton>
              </Text3>
            </li>
          </ul>
        </Block>
      </div>
      <div className={styles.actions}>
        <Skeleton className={styles.skeletonButton}>{getMockText(30)}</Skeleton>

        <Block offsetTop="s">
          <ul className={styles.actionsList}>
            <li>
              <Skeleton>{getMockText(15)}</Skeleton>
            </li>
          </ul>
        </Block>
      </div>
    </div>
  );
};
