import { useUpdateSearchParams } from "@app/hooks/useUpdateSearchParams";
import cn from "classnames";
import { FC } from "react";
import { NavLink } from "react-router-dom";

import styles from "./index.module.scss";

type Props = {
  page: number;
  isNext?: boolean;
  isPrevious?: boolean;
  isActive?: boolean;
};

export const Item: FC<Props> = ({ page, isNext, isActive, isPrevious }) => {
  const { searchParams } = useUpdateSearchParams();
  const nextSearchParams = new URLSearchParams(searchParams);
  nextSearchParams.set("page", String(page));

  return (
    <li className={styles.item}>
      <NavLink
        to={`/users?${nextSearchParams.toString()}`}
        className={cn(styles.link, isActive && styles.active)}
      >
        {isNext ? ">>" : isPrevious ? "<<" : page}
      </NavLink>
    </li>
  );
};
