export const LIMIT_OF_AVAILABLE_PAGES = 3;

export const getAvailablePages = (currentPage: number, countOfPage: number) => {
  if (currentPage > countOfPage) {
    return [];
  }

  const availablePages = [currentPage];
  const numOfShownPages = Math.min(LIMIT_OF_AVAILABLE_PAGES, countOfPage);

  let left = currentPage - 1;
  let right = currentPage + 1;

  while (availablePages.length < numOfShownPages) {
    if (left > 0 && availablePages.length < numOfShownPages) {
      availablePages.unshift(left);
      left--;
    }

    if (right <= countOfPage && availablePages.length < numOfShownPages) {
      availablePages.push(right);
      right++;
    }
  }

  return availablePages;
};
