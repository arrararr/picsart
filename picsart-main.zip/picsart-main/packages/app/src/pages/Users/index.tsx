import { useUpdateSearchParams } from "@app/hooks/useUpdateSearchParams";
import { checkIfShouldShowPagination } from "@app/stores/userFilter";
import { getUserIds, resetUserIds } from "@app/stores/userIds";
import { checkIfFetchingUsers } from "@app/stores/users";
import { FC, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";

import { Block } from "@ui-kit/components/Grid";
import { H1 } from "@ui-kit/typography";

import { UsersList, UsersSkeleton } from "./components";
import { Pagination, UsersFilter } from "./components";
import styles from "./index.module.scss";
import { useListenFilters } from "./useListenFilters";

const Users: FC = () => {
  const shouldShowPagination = useSelector(checkIfShouldShowPagination);
  const userIds = useSelector(getUserIds);
  const shouldShowSkeleton = useSelector(checkIfFetchingUsers);
  const hasUsers = userIds.length > 0;
  const dispatch = useDispatch();
  const { searchParams, updateParam } = useUpdateSearchParams();
  useListenFilters(searchParams);

  useEffect(() => {
    return () => {
      dispatch(resetUserIds());
    };
  }, [dispatch]);

  return (
    <div>
      <H1>Users</H1>
      <Block offsetTop="s" className={styles.content}>
        <div className={styles.users}>
          {shouldShowSkeleton ? (
            <UsersSkeleton />
          ) : hasUsers ? (
            <UsersList userIds={userIds} />
          ) : (
            "No users"
          )}
          {shouldShowPagination && (
            <Block offsetTop="l" className={styles.pagination}>
              <Pagination />
            </Block>
          )}
        </div>
        <UsersFilter className={styles.filter} onChange={updateParam} />
      </Block>
    </div>
  );
};

export default Users;
