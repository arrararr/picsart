import { Dispatch } from "@app/stores/types";
import { setPage, setSearch, setSort } from "@app/stores/userFilter";
import { getUserIds } from "@app/stores/userIds";
import { fetchUsers } from "@app/stores/users";
import { useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";

export const useListenFilters = (searchParams: URLSearchParams) => {
  const userIds = useSelector(getUserIds);
  const page = Number(searchParams.get("page") || 1);
  const sort = searchParams.get("sort") || "";
  const search = searchParams.get("search") || "";
  const shouldRequestUsers = useRef(!userIds.length);

  const dispatch = useDispatch<Dispatch>();

  useEffect(() => {
    if (shouldRequestUsers.current) {
      dispatch(fetchUsers({ page, sort, search }));
    }
    shouldRequestUsers.current = true;
  }, [dispatch, page, sort, search]);

  useEffect(() => {
    dispatch(setPage(page));
  }, [dispatch, page]);

  useEffect(() => {
    dispatch(setSort(sort));
  }, [dispatch, sort]);

  useEffect(() => {
    dispatch(setSearch(search));
  }, [dispatch, search]);
};
