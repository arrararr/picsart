import { Dispatch } from "@app/stores/types";
import {
  checkIfUserAddingError,
  checkIfUserAddingFulfilled,
  checkIfUserIsAdding,
} from "@app/stores/user";
import { addUser } from "@app/stores/user/actions";
import { FC, FormEvent, useCallback, useId, useReducer, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

import {
  Button,
  ButtonStyle,
  FileUploader,
  Label,
  TextField,
} from "@ui-kit/components";
import { ErrorMessage } from "@ui-kit/components/ErrorMessage";
import { Block } from "@ui-kit/components/Grid";
import { H1, Text3 } from "@ui-kit/typography";

import styles from "./index.module.scss";

type UserForm = {
  file: File | null;
  name: string;
  lastName: string;
  age: string;
  email: string;
  address: string;
  description: string;
};

type Action = {
  type: keyof UserForm;
  value: string | File | null;
};

const INITIAL_FORM_STATE: UserForm = {
  file: null,
  name: "",
  lastName: "",
  age: "",
  email: "",
  address: "",
  description: "",
};

const reducer = (state: UserForm, action: Action) => {
  return { ...state, [action.type]: action.value };
};

const removeNotNumber = (value: string) => value.replace(/\D/gi, "");

const Home: FC = () => {
  const [state, saveState] = useReducer(reducer, INITIAL_FORM_STATE);
  const dispatch = useDispatch<Dispatch>();
  const [shouldShowFileError, setShouldShowFileError] = useState(false);

  const isLoading = useSelector(checkIfUserIsAdding);
  const isError = useSelector(checkIfUserAddingError);
  const isSuccess = useSelector(checkIfUserAddingFulfilled);

  const nameId = useId();
  const lastNameId = useId();
  const ageId = useId();
  const emailId = useId();
  const descriptionId = useId();
  const fileId = useId();
  const addressId = useId();

  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!(e.target instanceof HTMLFormElement)) return;

    dispatch(addUser(state));
  };

  const fileHandler = useCallback((files: FileList) => {
    const [file] = files;
    const isImage = file && file.type.match("image.*");
    const maxSize = 1 * 1024 * 1024;

    if (file && isImage && file.size < maxSize) {
      setShouldShowFileError(false);
      return saveState({
        type: "file",
        value: file,
      });
    }

    return setShouldShowFileError(true);
  }, []);

  return (
    <div className={styles.root}>
      <H1>Add user</H1>
      <Block offsetTop="s">
        <form method="POST" className={styles.form} onSubmit={onSubmit}>
          <div className={styles.fields}>
            <div className={styles.textFields}>
              <Label text="Name" id={nameId}>
                <TextField
                  id={nameId}
                  isRequired={true}
                  value={state.name}
                  onChange={(value) =>
                    saveState({
                      type: "name",
                      value,
                    })
                  }
                />
              </Label>
              <Block offsetTop="s">
                <Label text="Last name" id={lastNameId}>
                  <TextField
                    id={lastNameId}
                    isRequired={true}
                    value={state.lastName}
                    onChange={(value) =>
                      saveState({
                        type: "lastName",
                        value,
                      })
                    }
                  />
                </Label>
              </Block>
              <Block offsetTop="s">
                <Label text="Age" id={ageId}>
                  <TextField
                    id={ageId}
                    isRequired={true}
                    value={state.age}
                    maskingValue={removeNotNumber}
                    onChange={(value) =>
                      saveState({
                        type: "age",
                        value: removeNotNumber(value),
                      })
                    }
                  />
                </Label>
              </Block>
              <Block offsetTop="s">
                <Label text="Email" id={emailId}>
                  <TextField
                    id={emailId}
                    isRequired={true}
                    type="email"
                    value={state.email}
                    onChange={(value) =>
                      saveState({
                        type: "email",
                        value,
                      })
                    }
                  />
                </Label>
              </Block>

              <Block offsetTop="s">
                <Label text="Address" id={addressId}>
                  <TextField
                    id={addressId}
                    isRequired={true}
                    value={state.address}
                    onChange={(value) =>
                      saveState({
                        type: "address",
                        value,
                      })
                    }
                  />
                </Label>
              </Block>

              <Block offsetTop="s">
                <Label text="Description" id={descriptionId}>
                  <TextField
                    id={descriptionId}
                    isRequired={true}
                    isMultiline={true}
                    value={state.description}
                    onChange={(value) =>
                      saveState({
                        type: "description",
                        value,
                      })
                    }
                  />
                </Label>
              </Block>
            </div>
            <div className={styles.fileUploaderContainer}>
              <FileUploader
                id={fileId}
                className={styles.fileUploader}
                onChange={fileHandler}
                name="file"
                isRequired={true}
              />
              {shouldShowFileError && (
                <Block offsetTop="s">
                  <ErrorMessage>
                    Max size is 3mb and only image accepted
                  </ErrorMessage>
                </Block>
              )}
            </div>
          </div>

          {isError && (
            <Block offsetTop="s">
              <ErrorMessage>
                Something went wrong. Please try again
              </ErrorMessage>
            </Block>
          )}

          {isSuccess && (
            <Block offsetTop="s">
              <Text3 className={styles.success}>
                The user has been successfully saved
              </Text3>
            </Block>
          )}

          <Block className={styles.buttons} offsetTop="s">
            <Button
              buttonStyle={ButtonStyle.Primary}
              type="submit"
              isDisabled={isLoading}
            >
              Add user
            </Button>
          </Block>
        </form>
      </Block>
    </div>
  );
};

export default Home;
