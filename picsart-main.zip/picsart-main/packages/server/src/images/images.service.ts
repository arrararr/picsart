import { Injectable } from '@nestjs/common';
import { basename, dirname, extname, join } from 'path';
import sharp, { FormatEnum } from 'sharp';

import { QUALITY } from './images.const';

@Injectable()
export class ImagesService {
  constructor() {}

  async prepareImage(
    inputPath: string,
    format: keyof FormatEnum,
    options: { width: number; height: number },
  ): Promise<string> {
    const extension = format;
    const name = basename(inputPath, extname(inputPath));
    const directory = dirname(inputPath);
    const outputPath = join(
      directory,
      `${name}_${options.width}_${options.height}.${extension}`,
    );

    await sharp(inputPath)
      .toFormat(format)
      .resize(options.width, options.height)
      [format]({ quality: QUALITY })
      .toFile(outputPath);

    return outputPath;
  }

  prepareImagesForAvatar(inputPath: string) {
    return Promise.all([
      this.prepareImage(inputPath, 'webp', { width: 100, height: 100 }),
      this.prepareImage(inputPath, 'webp', { width: 200, height: 200 }),
      this.prepareImage(inputPath, 'webp', { width: 400, height: 400 }),
      this.prepareImage(inputPath, 'png', { width: 100, height: 100 }),
      this.prepareImage(inputPath, 'png', { width: 200, height: 200 }),
      this.prepareImage(inputPath, 'png', { width: 400, height: 400 }),
    ]);
  }
}
