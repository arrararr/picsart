export const QUALITY = 80;
export const MAX_FILE_SIZE = 1 * 1024 * 1024;
