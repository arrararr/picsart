import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { MulterModule } from '@nestjs/platform-express';

import { ApiModule } from './api/api.module';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ImagesModule } from './images/images.module';
import { PagesModule } from './pages/pages.module';
import { StoreModule } from './store/store.module';
import { UsersModule } from './users/users.module';

@Module({
  imports: [
    MulterModule.register(),
    MongooseModule.forRoot(
      // I know, this data shouldn't be here, but this is just DB only for one challenge
      'mongodb+srv://arrararr:tIU1cD3hmqqdqtvF@cluster0.tr325e8.mongodb.net/picsart?retryWrites=true&w=majority',
    ),
    ImagesModule,
    UsersModule,
    ApiModule,
    PagesModule,
    StoreModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
