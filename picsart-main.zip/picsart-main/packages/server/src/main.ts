import { NestFactory } from '@nestjs/core';
import { NestExpressApplication } from '@nestjs/platform-express';
import cookieParser from 'cookie-parser';

import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);
  app.enableCors({
    // for dev
    origin: 'http://localhost:3001',
    methods: 'GET,POST,PUT,DELETE',
  });
  app.use(cookieParser());

  /*  app.useStaticAssets(join(__dirname, '..', '..', '..', 'dist'), {
    prefix: '/static/',
  });
  app.useStaticAssets(join(__dirname, '..', 'uploads'), {
    prefix: '/images/',
  });*/

  await app.listen(3001);
}
bootstrap();
