import { UserState } from '@app/stores/user';
import { Pagination, UserFilterState } from '@app/stores/userFilter';
import { UserIdsState } from '@app/stores/userIds';
import { UsersState } from '@app/stores/users';
import { Injectable } from '@nestjs/common';

import { UserDto } from '@server/users/dto/user.dto';

type UserFilter = {
  sort: string;
  search: string;
};

@Injectable()
export class StoreService {
  prepareUsers(users: UserDto[]): UsersState {
    return {
      users: users.reduce((acc, user) => {
        acc[user._id] = {
          _id: String(user._id),
          name: user.name,
          lastName: user.lastName,
          email: user.email,
          age: user.age,
          description: user.description,
          address: user.address,
        };

        return acc;
      }, {}),
    };
  }

  prepareUserIds(users: UserDto[]): UserIdsState {
    return users.map(({ _id }) => _id);
  }

  prepareUserFilter(
    pagination: Pagination,
    { sort, search }: UserFilter,
  ): UserFilterState {
    return {
      sort,
      search,
      pagination: {
        total: pagination.total,
        page: pagination.page + 1,
      },
    };
  }

  prepareUser(user: UserDto): UserState {
    return {
      user: {
        _id: String(user._id),
        age: String(user.age),
        name: user.name,
        lastName: user.lastName,
        address: user.address,
        email: user.email,
        description: user.description,
      },
    };
  }
}
