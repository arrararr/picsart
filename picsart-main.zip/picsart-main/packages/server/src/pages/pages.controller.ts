import { Controller, Get, Param, Query, Req, Res } from '@nestjs/common';
import { Response, Request } from 'express';

import { PagesService } from './pages.service';

@Controller('')
export class PagesController {
  constructor(private readonly pagesService: PagesService) {}

  @Get()
  async home(@Req() req: Request, @Res() res: Response) {
    return this.pagesService.renderHome(req, res);
  }

  @Get('/users')
  users(
    @Req() req: Request,
    @Res() res: Response,
    @Query('page') page: string,
    @Query('sort') sort: string,
    @Query('search') search: string,
  ) {
    return this.pagesService.renderUsers(req, res, { page, sort, search });
  }

  @Get('/users/:id')
  user(@Req() req: Request, @Res() res: Response, @Param('id') id: string) {
    return this.pagesService.renderUser(req, res, id);
  }
}
