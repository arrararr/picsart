import { Module } from '@nestjs/common';

import { StoreModule } from '@server/store/store.module';

import { UsersModule } from '../users/users.module';

import { PagesController } from './pages.controller';
import { PagesService } from './pages.service';

@Module({
  controllers: [PagesController],
  imports: [UsersModule, StoreModule],
  providers: [PagesService],
})
export class PagesModule {}
