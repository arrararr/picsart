import { Injectable, NotFoundException, Req, Res } from '@nestjs/common';
import { Response, Request } from 'express';
import mongoose from 'mongoose';
import * as React from 'react';
import * as ReactDOMServer from 'react-dom/server';

import { StoreService } from '@server/store/store.service';
import { UsersService } from '@server/users/users.service';

import { SSR } from './pages.ssr';

type RenderUser = {
  page: string;
  search: string;
  sort: string;
};

@Injectable()
export class PagesService {
  constructor(
    private readonly usersService: UsersService,
    private readonly storeService: StoreService,
  ) {}

  getTheme(@Req() req: Request) {
    return req.cookies['theme'] || 'light';
  }

  renderPage(
    @Res() res: Response,
    el: React.FunctionComponentElement<React.ComponentProps<typeof SSR>>,
  ) {
    let didError = false;

    const { pipe, abort } = ReactDOMServer.renderToPipeableStream(el, {
      onShellReady() {
        res.statusCode = didError ? 500 : 200;
        res.setHeader('Content-type', 'text/html');
        pipe(res);
      },
      onError(error) {
        didError = true;
        console.error(error);
        abort();
      },
    });

    res.on('close', () => {
      abort();
    });
  }

  async renderHome(@Req() req: Request, @Res() res: Response) {
    const el = React.createElement(SSR, {
      page: '/',
      preloadedState: {
        ui: {
          theme: this.getTheme(req),
        },
      },
    });

    return this.renderPage(res, el);
  }

  async renderUsers(
    @Req() req: Request,
    @Res() res: Response,
    { page, sort = '', search = '' }: RenderUser,
  ) {
    const { users, pagination } = await this.usersService.getRecords({
      page: (Number(page) || 1) - 1,
      search,
      sort: sort.trim() || '_id',
    });

    const el = React.createElement(SSR, {
      page: '/users',
      preloadedState: {
        users: this.storeService.prepareUsers(users),
        userIds: this.storeService.prepareUserIds(users),
        userFilter: this.storeService.prepareUserFilter(pagination, {
          sort,
          search,
        }),
        ui: {
          theme: this.getTheme(req),
        },
      },
    });

    return this.renderPage(res, el);
  }

  async renderUser(@Req() req: Request, @Res() res: Response, id: string) {
    if (!mongoose.Types.ObjectId.isValid(id)) {
      throw new NotFoundException(`Item with ID ${id} not found`);
    }

    const user = await this.usersService.getUserById(id);

    if (!user) {
      throw new NotFoundException(`Item with ID ${id} not found`);
    }

    const el = React.createElement(SSR, {
      page: `/users/${id}`,
      preloadedState: {
        user: this.storeService.prepareUser(user),
        ui: {
          theme: this.getTheme(req),
        },
      },
    });

    return this.renderPage(res, el);
  }
}
