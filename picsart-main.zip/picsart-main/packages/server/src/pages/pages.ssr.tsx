import Entry from '@app/entry';
import { PreloadedState } from '@app/stores/types';
import { UiState } from '@app/stores/ui';
import { UserState } from '@app/stores/user';
import { UserFilterState } from '@app/stores/userFilter';
import { UserIdsState } from '@app/stores/userIds';
import { UsersState } from '@app/stores/users';
import {
  configureStore,
  createSlice,
  SliceCaseReducers,
} from '@reduxjs/toolkit';
import * as React from 'react';
import { Provider } from 'react-redux';
import { StaticRouter } from 'react-router-dom/server';

type Props = {
  page: string;
  preloadedState: PreloadedState;
};

function initializeStore(preloadedState: PreloadedState = {}) {
  const users = createSlice<UsersState, SliceCaseReducers<UsersState>>({
    name: 'users',
    initialState: preloadedState.users || {
      users: {},
    },
    reducers: {},
  });

  const user = createSlice<UserState, SliceCaseReducers<UserState>>({
    name: 'user',
    initialState: preloadedState.user || {
      user: null,
    },
    reducers: {},
  });

  const userIds = createSlice<UserIdsState, SliceCaseReducers<UserIdsState>>({
    name: 'userIds',
    initialState: preloadedState.userIds || [],
    reducers: {},
  });

  const userFilter = createSlice<
    UserFilterState,
    SliceCaseReducers<UserFilterState>
  >({
    name: 'userFilter',
    initialState: preloadedState.userFilter || {
      sort: null,
      search: null,
      pagination: null,
    },
    reducers: {},
  });

  const ui = createSlice<UiState, SliceCaseReducers<UiState>>({
    name: 'ui',
    initialState: preloadedState.ui || {
      theme: 'light',
    },
    reducers: {},
  });

  return configureStore({
    reducer: {
      ui: ui.reducer,
      user: user.reducer,
      users: users.reducer,
      userIds: userIds.reducer,
      userFilter: userFilter.reducer,
    },
  });
}

export const SSR: React.FC<Props> = ({ page, preloadedState }) => (
  <Provider store={initializeStore(preloadedState)}>
    <StaticRouter location={page}>
      <Entry preloadedState={preloadedState} />
    </StaticRouter>
  </Provider>
);
