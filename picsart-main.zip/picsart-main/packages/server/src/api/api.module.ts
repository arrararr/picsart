import { Module } from '@nestjs/common';

import { ImagesModule } from '@server/images/images.module';
import { UsersModule } from '@server/users/users.module';

import { ApiController } from './api.controller';

@Module({
  controllers: [ApiController],
  imports: [UsersModule, ImagesModule],
})
export class ApiModule {}
