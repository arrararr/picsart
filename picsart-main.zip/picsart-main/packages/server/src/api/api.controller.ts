import {
  Controller,
  Get,
  Delete,
  Post,
  Param,
  Body,
  Put,
  Query,
  Header,
  UseInterceptors,
  UploadedFile,
  ParseFilePipe,
  MaxFileSizeValidator,
  FileTypeValidator,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { extname } from 'path';

import { MAX_FILE_SIZE } from '@server/images/images.const';

import { ImagesService } from '../images/images.service';
import { CreateUserDto } from '../users/dto/create-user.dto';
import { GetUsersDto } from '../users/dto/get-users.dto';
import { UpdateUserDto } from '../users/dto/update-user.dto';
import { User } from '../users/schemas/user-schema';
import { UsersService } from '../users/users.service';

@Controller('api')
export class ApiController {
  constructor(
    private readonly usersService: UsersService,
    private readonly imagesService: ImagesService,
  ) {}

  @Get('/users')
  async getUsers(
    @Query('page') page: string,
    @Query('sort') sort: string,
    @Query('search') search: string,
  ): Promise<GetUsersDto> {
    const pageNumber = Number(page) || 0;
    return this.usersService.getRecords({ page: pageNumber, search, sort });
  }

  @Get('/users/:id')
  async getUserById(@Param('id') id: string): Promise<User> {
    return this.usersService.getUserById(id);
  }

  @Delete('/users/:id')
  async removeUserById(@Param('id') id: string): Promise<User> {
    return this.usersService.remove(id);
  }

  @Post('/users/create')
  @Header('Content-Type', 'application/json')
  createUser(@Body() createUserDto: CreateUserDto): Promise<User> {
    return this.usersService.create(createUserDto);
  }

  @Post('/images/upload/:id')
  @UseInterceptors(
    FileInterceptor('file', {
      storage: diskStorage({
        destination: './uploads',
        filename: (req, file, callback) => {
          const fileExtName = extname(file.originalname);
          const customFileName = `${req.params.id}${fileExtName}`;
          callback(null, customFileName);
        },
      }),
    }),
  )
  async imagesUpload(
    @UploadedFile(
      new ParseFilePipe({
        validators: [
          new MaxFileSizeValidator({ maxSize: MAX_FILE_SIZE }),
          new FileTypeValidator({ fileType: /image\/(jpeg|jpg|png|gif)/ }),
        ],
      }),
    )
    file: Express.Multer.File,
  ) {
    const images = await this.imagesService.prepareImagesForAvatar(file.path);

    return images;
  }

  @Put('/users/:id')
  updateUser(
    @Body() updateUserDto: UpdateUserDto,
    @Param('id') id: string,
  ): Promise<User> {
    return this.usersService.update(id, updateUserDto);
  }
}
