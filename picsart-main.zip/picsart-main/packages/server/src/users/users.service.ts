import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';

import { CreateUserDto } from './dto/create-user.dto';
import { GetUsersDto } from './dto/get-users.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { UserDto } from './dto/user.dto';
import { User, UserDocument } from './schemas/user-schema';

type GetRecords = {
  page: number;
  search: string;
  sort: string;
};

@Injectable()
export class UsersService {
  constructor(@InjectModel(User.name) private userModel: Model<UserDocument>) {}

  async getRecords({
    page = 0,
    search = '',
    sort = '_id',
  }: GetRecords): Promise<GetUsersDto> {
    const limit = 10;
    const searchRegex = new RegExp(search, 'i');

    const totalCountPromise = this.userModel
      .countDocuments({
        $expr: {
          $regexMatch: {
            input: { $concat: ['$name', ' ', '$lastName'] },
            regex: searchRegex,
          },
        },
      })
      .exec();
    const recordsPromise = this.userModel
      .aggregate([
        {
          $addFields: {
            fullName: { $concat: ['$name', ' ', '$lastName'] },
          },
        },
        {
          $match: {
            fullName: searchRegex,
          },
        },
        {
          $sort: { [sort]: 1 },
        },
        {
          $skip: page * limit,
        },
        {
          $limit: limit,
        },
      ])
      .exec();

    const [total, users] = await Promise.all([
      totalCountPromise,
      recordsPromise,
    ]);

    return {
      pagination: {
        total,
        page,
        limit,
      },
      users,
    };
  }

  async getUserById(id: string): Promise<UserDto> {
    return this.userModel.findById(id);
  }

  async create(userDTO: CreateUserDto): Promise<UserDto> {
    const newUser = new this.userModel(userDTO);
    return newUser.save();
  }

  async remove(id: string): Promise<UserDto> {
    return this.userModel.findByIdAndDelete(id);
  }

  async update(id: string, userDTO: UpdateUserDto): Promise<UserDto> {
    return this.userModel.findByIdAndUpdate(id, userDTO, { new: true });
  }
}
