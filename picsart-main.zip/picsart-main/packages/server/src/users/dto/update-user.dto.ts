import { UserDto } from './user.dto';

export type UpdateUserDto = Omit<UserDto, 'id'>;
