export class UserDto {
  readonly _id: string;
  readonly name: string;
  readonly lastName: string;
  readonly email: string;
  readonly age: number;
  readonly address: string;
  readonly image: string;
  readonly description: string;
}
