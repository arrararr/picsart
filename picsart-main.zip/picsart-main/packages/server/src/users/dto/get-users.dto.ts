import { UserDto } from './user.dto';

export class GetUsersDto {
  readonly users: UserDto[];
  readonly pagination: {
    total: number;
    page: number;
    limit: number;
  };
}
