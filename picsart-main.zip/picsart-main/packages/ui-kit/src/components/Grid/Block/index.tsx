import cn from "classnames";
import { FC, PropsWithChildren } from "react";

import styles from "./index.module.scss";

type Sizes = "l" | "s" | "xs" | "xxs";
type SizesLeft = "s";

type Props = {
  className?: string;
  offsetTop?: Sizes;
  offsetLeft?: SizesLeft;
};

export const Block: FC<PropsWithChildren<Props>> = ({
  children,
  offsetTop,
  offsetLeft,
  className,
}) => {
  return (
    <div
      className={cn([
        offsetTop && styles[`offsetTop-${offsetTop}`],
        offsetLeft && styles[`offsetLeft-${offsetLeft}`],
        className,
      ])}
    >
      {children}
    </div>
  );
};
