import cn from "classnames";
import { FC, PropsWithChildren } from "react";

import styles from "./index.module.scss";

type Props = {
  className?: string;
};

export const Container: FC<PropsWithChildren<Props>> = ({
  children,
  className,
}) => {
  return <div className={cn(styles.root, className)}>{children}</div>;
};
