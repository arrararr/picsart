import cn from "classnames";
import { FC, PropsWithChildren } from "react";

import styles from "./styles.module.scss";

type Props = {
  className?: string;
  dataQaIdBase?: string;
};

export const ErrorMessage: FC<PropsWithChildren<Props>> = ({
  children,
  className,
  dataQaIdBase = "errorMessage",
}) => {
  return (
    <div
      data-qa-id={`${dataQaIdBase}_error`}
      className={cn([styles.root, className])}
    >
      {children}
    </div>
  );
};
