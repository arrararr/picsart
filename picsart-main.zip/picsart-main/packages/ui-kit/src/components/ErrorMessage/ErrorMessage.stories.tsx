import type { Meta, StoryObj } from "@storybook/react";

import { ErrorMessage } from "./";

type Story = StoryObj<typeof ErrorMessage>;

export const Default: Story = {
  args: {
    children: "Something went wrong",
  },
};

const meta: Meta<typeof ErrorMessage> = {
  component: ErrorMessage,
};

export default meta;
