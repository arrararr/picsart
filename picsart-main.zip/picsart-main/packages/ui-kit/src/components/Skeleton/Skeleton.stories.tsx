import type { Meta, StoryObj } from "@storybook/react";

import { getMockText } from "@ui-kit/helpers/getMockText";

import { Skeleton } from "./";

type Story = StoryObj<typeof Skeleton>;

export const Default: Story = {
  args: {
    children: getMockText(30),
  },
};

const meta: Meta<typeof Skeleton> = {
  component: Skeleton,
};

export default meta;
