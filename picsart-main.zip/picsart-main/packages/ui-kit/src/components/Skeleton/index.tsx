import cn from "classnames";
import { FC, PropsWithChildren } from "react";

import styles from "./styles.module.scss";

type Props = {
  className?: string;
};

export const Skeleton: FC<PropsWithChildren<Props>> = ({
  className,
  children,
}) => {
  return <div className={cn(styles.root, className)}>{children}</div>;
};
