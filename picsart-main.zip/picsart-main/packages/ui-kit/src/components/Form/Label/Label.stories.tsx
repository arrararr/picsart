import type { Meta, StoryObj } from "@storybook/react";

import { TextField } from "@ui-kit/components";

import { Label } from "./";

type Story = StoryObj<typeof Label>;

export const Default: Story = {
  args: {
    text: "some label",
    children: <TextField value="value" id={"id"} />,
  },
};

const meta: Meta<typeof Label> = {
  component: Label,
};

export default meta;
