import cn from "classnames";
import { FC, PropsWithChildren } from "react";

import { H4 } from "@ui-kit/typography";

import styles from "./index.module.scss";

type LabelProps = {
  id: string;
  text: string;
  className?: string;
};

export const Label: FC<PropsWithChildren<LabelProps>> = ({
  id,
  text,
  className,
  children,
}) => {
  return (
    <label className={cn(styles.label, className)} htmlFor={id}>
      <H4 as="div">{text}</H4>
      <div className={styles.input}>{children}</div>
    </label>
  );
};
