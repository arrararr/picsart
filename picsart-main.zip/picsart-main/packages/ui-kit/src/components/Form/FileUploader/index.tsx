import cn from "classnames";
import {
  useState,
  useCallback,
  DragEvent,
  ChangeEvent,
  useRef,
  FC,
  PropsWithChildren,
} from "react";

import styles from "./index.module.scss";

type Props = {
  id: string;
  className?: string;
  name: string;
  isRequired?: boolean;
  onChange: (files: FileList) => void;
};

export const FileUploader: FC<PropsWithChildren<Props>> = ({
  id,
  className,
  name,
  onChange,
  isRequired,
}) => {
  const [dragOver, setDragOver] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadedFiles, setUploadedFiles] = useState<FileList | null>(null);

  const handleDragEnter = useCallback((e: DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(false);
  }, []);

  const handleDragOver = useCallback((e: DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleFiles = useCallback(
    (files: FileList) => {
      onChange(files);
    },
    [onChange],
  );

  const handleDrop = useCallback(
    (e: DragEvent<HTMLLabelElement>) => {
      e.preventDefault();
      e.stopPropagation();
      setDragOver(false);

      const files = e.dataTransfer.files;
      handleFiles(files);
    },
    [handleFiles],
  );

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      handleFiles(e.target.files);
      setUploadedFiles(e.target.files);
    }
  };

  return (
    <label
      htmlFor={id}
      className={cn(styles.dropZone, dragOver && styles.dragOver, className)}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
    >
      {uploadedFiles?.length
        ? new Array(uploadedFiles.length)
            .fill(0)
            .map((item, index) => uploadedFiles[item + index].name)
            .join(", ")
        : "Drag files here or click to upload."}
      <input
        id={id}
        ref={fileInputRef}
        type="file"
        accept=".png, .jpg, .jpeg"
        name={name}
        onChange={handleChange}
        required={isRequired}
        className={styles.inputFile}
      />
    </label>
  );
};
