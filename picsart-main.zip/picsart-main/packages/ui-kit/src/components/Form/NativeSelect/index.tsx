import cn from "classnames";
import { FC } from "react";

import { Text3 } from "@ui-kit/typography";

import styles from "./index.module.scss";

export type Option = {
  label: string;
  value: string;
};

type Props = {
  id: string;
  onChange: (value: string) => void;
  options: Option[];
  value?: string;
  className?: string;
  errorText?: string;
  hasError?: boolean;
  isDisabled?: boolean;
};

export const NativeSelect: FC<Props> = (props) => {
  const {
    id,
    onChange,
    options,
    className,
    value,
    hasError,
    errorText,
    isDisabled,
  } = props;

  return (
    <>
      <div
        className={cn(
          styles.root,
          isDisabled && styles.disabledRoot,
          className,
        )}
      >
        <select
          id={id}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className={styles.select}
          disabled={isDisabled}
        >
          {options.map(({ label, value }, index) => (
            <option value={value} key={index}>
              {label}
            </option>
          ))}
        </select>
      </div>
      <div className={styles.bottom}>
        {hasError && errorText ? (
          <Text3 className={styles.errorText}>{errorText}</Text3>
        ) : null}
      </div>
    </>
  );
};
