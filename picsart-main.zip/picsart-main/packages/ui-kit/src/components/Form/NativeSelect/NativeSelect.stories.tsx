import type { Meta, StoryObj } from "@storybook/react";

import { NativeSelect } from "./";

type Story = StoryObj<typeof NativeSelect>;

export const Default: Story = {
  args: {
    onChange: (value) => console.log(`next value is ${value}`),
    value: "1",
    options: [
      {
        label: "label",
        value: "1",
      },
      {
        label: "label2",
        value: "2",
      },
      {
        label: "label3",
        value: "3",
      },
    ],
  },
};

const meta: Meta<typeof NativeSelect> = {
  component: NativeSelect,
};

export default meta;
