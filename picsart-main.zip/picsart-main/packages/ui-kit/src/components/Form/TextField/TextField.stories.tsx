import type { Meta, StoryObj } from "@storybook/react";

import { TextField } from "./TextField";

type Story = StoryObj<typeof TextField>;

export const Default: Story = {
  args: {
    value: "some value",
    placeholder: "placeholder",
  },
};

const meta: Meta<typeof TextField> = {
  component: TextField,
};

export default meta;
