import cn from "classnames";
import debounce from "lodash.debounce";
import {
  ChangeEvent,
  FC,
  RefObject,
  useCallback,
  useEffect,
  useRef,
} from "react";

import { Text3 } from "@ui-kit/typography";

import styles from "./index.module.scss";

type TextFieldProps = {
  value: string;
  id: string;
  onChange?: (value: string) => void;
  className?: string;
  placeholder?: string;
  pattern?: string;
  isDisabled?: boolean;
  isRequired?: boolean;
  isMultiline?: boolean;
  hasError?: boolean;
  errorText?: string;
  lettersLimit?: number;
  type?: "text" | "password" | "date" | "number" | "email";
  maskingValue?: (value: string) => string;
};

const HANDLER_TIMEOUT_MS = 300;

export const TextField: FC<TextFieldProps> = ({
  id,
  value,
  onChange = () => undefined,
  className,
  placeholder = "",
  isMultiline = false,
  isDisabled = false,
  isRequired = false,
  hasError = false,
  type = "text",
  pattern,
  errorText,
  lettersLimit,
  maskingValue = (value: string) => value,
}) => {
  const input = useRef<HTMLInputElement | HTMLTextAreaElement>(null);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const handleChangeMemoized = useCallback(
    debounce(onChange, HANDLER_TIMEOUT_MS),
    [onChange],
  );

  const handleChange = (
    event: ChangeEvent<HTMLTextAreaElement | HTMLInputElement>,
  ) => {
    const nextValue =
      lettersLimit && event.target.value.length > lettersLimit
        ? event.target.value.slice(0, lettersLimit)
        : event.target.value;

    event.target.value = maskingValue(nextValue);
    handleChangeMemoized(nextValue);
  };

  useEffect(() => {
    if (input.current) {
      input.current.value = value;
    }
  }, [value]);

  const shouldShowExternalBlock = (hasError && errorText) || lettersLimit;

  if (isMultiline) {
    return (
      <>
        <textarea
          id={id}
          required={isRequired}
          className={cn(
            styles.textareaRoot,
            hasError && styles.error,
            className,
          )}
          ref={input as RefObject<HTMLTextAreaElement>}
          disabled={isDisabled}
          placeholder={placeholder}
          onChange={handleChange}
        />
        {shouldShowExternalBlock && (
          <div className={styles.bottom}>
            {hasError && errorText ? (
              <Text3 className={styles.errorText}>{errorText}</Text3>
            ) : null}
            {lettersLimit ? (
              <Text3
                className={cn(styles.limit, isDisabled && styles.disabled)}
              >
                {value.length}/{lettersLimit}
              </Text3>
            ) : null}
          </div>
        )}
      </>
    );
  }

  return (
    <>
      <input
        id={id}
        required={isRequired}
        className={cn(styles.textInput, hasError && styles.error, className)}
        type={type}
        ref={input as RefObject<HTMLInputElement>}
        pattern={pattern}
        disabled={isDisabled}
        placeholder={placeholder}
        onChange={handleChange}
      />
      {shouldShowExternalBlock && (
        <div className={styles.bottom}>
          {hasError && errorText ? (
            <Text3 className={styles.errorText}>{errorText}</Text3>
          ) : null}
        </div>
      )}
    </>
  );
};
