export enum ButtonStyle {
  Primary = "Primary",
  Secondary = "Secondary",
  Ghost = "Ghost",
}
