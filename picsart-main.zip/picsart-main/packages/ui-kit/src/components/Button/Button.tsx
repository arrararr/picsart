import cn from "classnames";
import { FC, PropsWithChildren } from "react";

import { ButtonStyle } from "./enums";
import styles from "./styles.module.scss";
import { Props } from "./types";

export const Button: FC<PropsWithChildren<Props>> = (props) => {
  const {
    children,
    type = "button",
    className = "",
    isActive = false,
    isDisabled = false,
    buttonStyle,
    onClick,
  } = props;

  const classNames = [
    styles.root,
    buttonStyle === ButtonStyle.Ghost && styles.ghost,
    buttonStyle === ButtonStyle.Primary && styles.primary,
    buttonStyle === ButtonStyle.Secondary && styles.secondary,
    className,
  ];

  return (
    <button
      type={type}
      className={cn(
        classNames,
        isActive && styles.active,
        isDisabled && styles.disabled,
      )}
      onClick={onClick}
      disabled={isDisabled}
    >
      {children}
    </button>
  );
};
