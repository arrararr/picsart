import { SyntheticEvent } from "react";

import { ButtonStyle } from "./enums";

export type Props = {
  buttonStyle: ButtonStyle;
  className?: string;
  isActive?: boolean;
  isDisabled?: boolean;
  type?: "button" | "submit" | "reset";
  href?: string;
  onClick?: (e: SyntheticEvent) => void;
};
