import type { Meta, StoryObj } from "@storybook/react";

import { Button } from "./Button";
import { ButtonStyle } from "./enums";

type Story = StoryObj<typeof Button>;

export const Default: Story = {
  args: {
    buttonStyle: ButtonStyle.Primary,
    children: "Button Text",
  },
};

const meta: Meta<typeof Button> = {
  component: Button,
};

export default meta;
