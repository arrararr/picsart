import type { Meta, StoryObj } from "@storybook/react";

import { Text2 as Text } from "./";

type Story = StoryObj<typeof Text>;

export const Default: Story = {
  args: {
    children: "Text for storybook",
  },
};

const meta: Meta<typeof Text> = {
  component: Text,
};

export default meta;
