import cn from "classnames";
import { FC, HTMLAttributes } from "react";

import { Typography } from "../Typography";

import styles from "./styles.module.scss";

type Props = {
  className?: string;
  as?: keyof JSX.IntrinsicElements;
  onClick?: (e: MouseEvent) => void;
};
export const Text3: FC<Props & HTMLAttributes<HTMLOrSVGElement>> = ({
  className,
  children,
  onClick,
  as: TagName = "span" as keyof JSX.IntrinsicElements,
}) => {
  return (
    <Typography
      className={cn([styles.root, className])}
      as={TagName}
      onClick={onClick}
    >
      <>{children}</>
    </Typography>
  );
};
