import cn from "classnames";
import { FC, HTMLAttributes } from "react";

import { H } from "../H";

import styles from "./styles.module.scss";

type Props = {
  className?: string;
  as?: keyof JSX.IntrinsicElements;
};
export const H3: FC<Props & HTMLAttributes<HTMLOrSVGElement>> = ({
  className,
  children,
  as: TagName = "h3" as keyof JSX.IntrinsicElements,
}) => {
  return (
    <H className={cn([styles.root, className])} as={TagName}>
      <>{children}</>
    </H>
  );
};
