import cn from "classnames";
import { FC, PropsWithChildren, HTMLAttributes } from "react";

import { Typography } from "../Typography";

import styles from "./styles.module.scss";

interface Props {
  className?: string;
  as: keyof JSX.IntrinsicElements;
}
export const H: FC<
  PropsWithChildren<Props & HTMLAttributes<HTMLOrSVGElement>>
> = ({ className, children, as: TagName }) => {
  return (
    <Typography className={cn([styles.root, className])} as={TagName}>
      <>{children}</>
    </Typography>
  );
};
