import type { Meta, StoryObj } from "@storybook/react";

import { H } from "./";

type Story = StoryObj<typeof H>;

export const Default: Story = {
  args: {
    children: "Text for storybook",
    as: "h1",
  },
};

const meta: Meta<typeof H> = {
  component: H,
};

export default meta;
