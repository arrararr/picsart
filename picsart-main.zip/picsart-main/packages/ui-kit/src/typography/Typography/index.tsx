import cn from "classnames";
import { FC, HTMLAttributes } from "react";

import styles from "./styles.module.scss";

interface Props {
  className?: string;
  as: keyof JSX.IntrinsicElements;
  onClick?: (e: MouseEvent) => void;
}
export const Typography: FC<Props & HTMLAttributes<HTMLOrSVGElement>> = ({
  className,
  children,
  as: TagName,
  onClick,
}) => {
  return (
    <TagName className={cn([styles.root, className])} onClick={onClick}>
      <>{children}</>
    </TagName>
  );
};
