import type { Meta, StoryObj } from "@storybook/react";

import { H4 as H } from "./";

type Story = StoryObj<typeof H>;

export const Default: Story = {
  args: {
    children: "Text for storybook",
  },
};

const meta: Meta<typeof H> = {
  component: H,
};

export default meta;
