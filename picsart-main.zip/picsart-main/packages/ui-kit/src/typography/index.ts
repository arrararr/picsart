export { H1 } from "./H1";
export { H2 } from "./H2";
export { H3 } from "./H3";
export { H4 } from "./H4";
export { Text } from "./Text";
export { Text2 } from "./Text2";
export { Text3 } from "./Text3";
