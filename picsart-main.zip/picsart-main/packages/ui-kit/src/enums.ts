export enum RequestStatus {
  Pending,
  Fulfilled,
  Rejected,
}
