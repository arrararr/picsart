type HttpMethod = "GET" | "POST" | "DELETE";

const httpRequest = async <T>(
  url: string,
  method: HttpMethod,
  body: BodyInit | null = null,
  headers: Record<string, string> = {},
): Promise<T> => {
  const config: RequestInit = {
    method,
    headers: {
      ...headers,
    },
  };

  if (body) {
    config.body = body;
  }

  try {
    const response = await fetch(
      `http://localhost:3000/${url.replace(/^\//, "")}`,
      config,
    );
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }
    return response.json();
  } catch (error) {
    console.error("Error in httpRequest:", error);
    throw error;
  }
};

export const get = <T>(url: string, headers?: Record<string, string>) =>
  httpRequest<T>(url, "GET", null, {
    "Content-Type": "application/json",
    ...headers,
  });
export const del = <T>(url: string, headers?: Record<string, string>) =>
  httpRequest<T>(url, "DELETE", null, headers);
export const post = <T>(
  url: string,
  body: BodyInit,
  headers?: Record<string, string>,
) => httpRequest<T>(url, "POST", body, headers);
