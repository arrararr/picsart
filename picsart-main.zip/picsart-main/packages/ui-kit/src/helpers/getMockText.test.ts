import { getMockText } from "./getMockText";

describe("getMockText", () => {
  test("should return a string of the specified length", () => {
    const length = 10;
    const result = getMockText(length);
    expect(result.length).toBe(length);
  });

  test("should return an empty string if length is 0", () => {
    const length = 0;
    const result = getMockText(length);
    expect(result).toBe("");
  });
});
