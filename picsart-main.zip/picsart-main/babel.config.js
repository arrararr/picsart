// @ts-check

/**
 * @type {import("@babel/core").ConfigFunction}
 */
module.exports = function () {
  /**
   * @type {import("@babel/core").PluginItem[]}
   */
  const plugins = ["@babel/plugin-transform-runtime"];

  return {
    plugins,
    presets: [
      [
        "@babel/preset-react",
        {
          runtime: "automatic",
        },
      ],
      ["@babel/preset-env"],
      [
        "@babel/preset-typescript",
        {
          isTSX: true,
          allExtensions: true,
        },
      ],
    ],
  };
};
