module.exports = {
  extends: ["@commitlint/config-conventional"],
  rules: {
    "subject-case": [2, "never"],
    "body-case": [2, "never"],
    "type-case": [2, "never"],
    "references-empty": [2, "never"],
  },
  parserPreset: {
    parserOpts: {
      referenceActions: null,
      issuePrefixes: ["PIC-"],
    },
  },
};
