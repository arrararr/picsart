import { State } from "@app/stores/types";

declare global {
  interface Window {
    REDUX_INITIAL_STATE?: State;
  }
}

export {};
