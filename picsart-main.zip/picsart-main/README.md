# picsart

## commands
* `docker compose up --build` - run whole app on port 3000

* `pnpm install` - install dependencies
* `pnpm -r --filter app run build:analyze` - get information about bundles
* `pnpm -r --filter ui-kit run storybook` - run ui-kit. I'm not sure if you need it


## Overview
This application is developed as a monorepo (pnpm workspaces). It contains 3 logical sections:
* `ui-kit` - includes reusable UI components and some helpers
* `server` - contains the server part
* `app` - encompasses the client part

The application was developed with a focus on high performance in Lighthouse. Necessary settings for code-splitting have been implemented, and some libraries have been moved to separate bundles. Some libraries are loaded from CDN. Server-side rendering is implemented, along with an Nginx proxy server and gzip compression.

## Pages
### `/`
The main page contains a form through which user information can be uploaded. When uploading a photo, it will be resized and cropped for use on devices with different pixel densities. The maximum uploadable photo size is 3MB.

### `/users`
On this page, you can filter and sort by different fields. Full name search is supported. Image optimization for devices with different pixel densities is implemented. Lazy image loading is also implemented. The search works with debounce. It's possible to delete a user.

I intentionally did not use useMemo, as there are not a lot of computations and complex renders on the page.

Pagination is implemented.

### `/user`
This page displays user information.

## Parts
### ui-kit
Implemented Storybook for easy viewing of UI components.
`pnpm storybook`

### server
The server part is implemented on Nest.js. I chose it because this framework supports TypeScript out of the box and makes it easy to implement the server part. MongoDB in the cloud was used as the database. I left the passwords directly in the code. I understand that this is not acceptable in real life :) I could have run Mongo in a Docker container, but I chose the cloud because it's faster.

### app
Client part:
`React 18`
`css-modules` - I chose this because I like writing styles in separate CSS files. If it's crucial, I can switch everything to styled-components.
`Redux` - chosen from the proposed options because it seems more convenient and extensible to me than ContextApi.

## What could be improved:
- I don't really like how I implemented TextFields. I would decouple them from the state. This could prevent page rerenders when entering text (e.g., on the home page).
- Handle the case when there is a maximum of 1 page, but a user tries to access the second one.
- Saving the user and the photo happens in 2 different requests. This means that the user might be saved, but the photo might not. I didn't make transactions and user deletion for such cases. So, in such a case, a broken image will be displayed on the page. To fix this, the requests could be swapped, saving the picture first, and the user information second. Thus, we would have an additional field in the DB with information about the picture. Currently, the picture's name is the user's id.
- I didn't write tests. If this is crucially important, I can do it.
- I did not implement smooth transitions between pages. If this is very important, I can do it.
- SSL and HTTP/2. The application runs locally on different computers, so I didn't do this.
